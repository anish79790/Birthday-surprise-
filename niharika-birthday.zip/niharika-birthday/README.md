# 🎀 SURPRISE.EXE - Niharika's Birthday Website

A retro 90s OS-inspired interactive birthday web app built for Niharika (Kuchu Puchu), styled in pastel pink, warm cream, and dark plum with a cute kawaii penguin, retro window chrome, and 7 interactive screens.

---

## 🚀 How to Run Locally

1. Open your terminal in this directory:
   ```bash
   npm install
   npm run dev
   ```
2. Open the local URL displayed (typically `http://localhost:5173`) in your phone or browser.

---

## 🌐 Instant 1-Click Free Deployment (To Share in Instagram DM)

### Option 1: Vercel (Recommended - Fastest & 100% Free)
1. Push this folder to a GitHub repository or drag-and-drop on [vercel.com](https://vercel.com).
2. Or run:
   ```bash
   npx vercel
   ```
3. Copy your live URL (e.g. `https://niharika-birthday.vercel.app`) and send it directly in an Instagram DM!

### Option 2: Netlify Drop (Zero Setup)
1. Run `npm run build` to generate the `dist` folder.
2. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
3. Drag and drop the `dist` folder.
4. You instantly get a live shareable URL!

### Option 3: GitHub Pages
1. Push to GitHub.
2. In Repository Settings -> Pages, select **GitHub Actions** with the Vite starter.
